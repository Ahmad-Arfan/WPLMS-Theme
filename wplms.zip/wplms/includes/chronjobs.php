<?php
/* ============ WPLMS Chron Jobs ============== */
/* 1. Email Remider for Course expiration
/* 2. Email reminder for Event expiration
/* 3. Email reminder for Assignment timer expiration.
/* ===============================================*/
